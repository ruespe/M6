//31. Crea un qüestionari amb els elements que s'indiquen en la imatge següent:
// Crea un script que desi els valors dels diferents camps quan s'introdueixin o hagi un canvi, de
// manera que si es tanca la finestra del navegador, quan es torni a obrir recuperi els valors
// introduïts fins el moment.
// El botó Reseteja ha d'eliminar les dades emmagatzemades.

const nombre = document.querySelector("#nombre");
const apellido = document.querySelector("#apellido");
const email = document.querySelector("#E-mail");
const direccion = document.querySelector("#Dirección");
const enviar = document.querySelector("#enviar");
const resetear = document.querySelector("#resetear");

window.addEventListener("load", () => {
  if (localStorage.getItem("nombre")) {
    nombre.value = localStorage.getItem("nombre");
  }
  if (localStorage.getItem("apellido")) {
    apellido.value = localStorage.getItem("apellido");
  }
  if (localStorage.getItem("email")) {
    email.value = localStorage.getItem("email");
  }
  if (localStorage.getItem("direccion")) {
    direccion.value = localStorage.getItem("direccion");
  }
});

nombre.addEventListener("input", (e) => {
  localStorage.setItem("nombre", e.target.value);
});

apellido.addEventListener("input", (e) => {
  localStorage.setItem("apellido", e.target.value);
});

email.addEventListener("input", (e) => {
  localStorage.setItem("email", e.target.value);
});

direccion.addEventListener("input", (e) => {
  localStorage.setItem("direccion", e.target.value);
});

enviar.addEventListener("click", (e) => {

  localStorage.setItem("nombre", nombre.value);
  localStorage.setItem("apellido", apellido.value);
  localStorage.setItem("email", email.value);
  localStorage.setItem("direccion", direccion.value);

});

resetear.addEventListener("click", (e) => {

  localStorage.removeItem("nombre");
  localStorage.removeItem("apellido");
  localStorage.removeItem("email");
  localStorage.removeItem("direccion");

  nombre.value = "";
  apellido.value = "";
  email.value = "";
  direccion.value = "";

});
